# SPDX-FileCopyrightText: 2024 Brad Barnett
#
# SPDX-License-Identifier: MIT
"""
`pdwidgets`
====================================================
Provides a collection of widgets for creating graphical user interfaces on embedded systems.
It includes base classes for widgets, as well as specific widgets such as buttons, labels, sliders, and more.

Core (always imported): Display, Screen, Task, Widget, themes, constants.

Widgets load lazily via ``__getattr__`` so MCU images only pay for modules you
touch. Lean path::

    from pdwidgets.widgets.button import Button

Convenience::

    import pdwidgets as pd
    pd.Button(...)  # imports widgets.button on first access

See ``widget-dependencies.md`` for the peer import graph.

Proportional fonts:
    ``Label`` (and widgets built on it) gains proportional-font rendering when a
    ``font`` module is supplied. That path uses the private
    :mod:`pdwidgets._write_font` helper (fonts from ``write_font_converter``).

Timer architecture:
    pdwidgets owns **no** timer of its own. Each :class:`Display` wires itself
    into the shared ``appdev.App`` at construction. Apps build the UI,
    then ``app.run()``.
"""

import events
from pygraphics import Area

from . import pct
from ._constants import (
    ALIGN,  #: Widget alignment flags (``ALIGN.TOP_LEFT``, ``ALIGN.CENTER``, …).
    DEFAULT_PADDING,  #: Default ``(PAD, PAD, PAD, PAD)`` inset for widgets.
    ICON_SIZE,  #: Valid icon sizes: ``SMALL`` (18), ``MEDIUM`` (24), ``LARGE`` (36), ``XLARGE`` (48).
    PAD,  #: Default padding unit in pixels (2).
    POSITION,  #: Bit flags combined into :data:`ALIGN` (``LEFT``, ``TOP``, ``OUTER``, …).
    TEXT_SIZE,  #: Romfont heights: ``SMALL`` (8), ``MEDIUM`` (14), ``LARGE`` (16).
    TEXT_WIDTH,  #: Fixed romfont character width in pixels (8).
)
from ._themes import ColorTheme, IconTheme, get_palette, icon_theme
from .display import Display, tick
from .screen import Screen
from .task import Task
from .widget import Widget

DEBUG = False  #: When ``True``, enable extra debug logging in pdwidgets.
MARK_UPDATES = False  #: When ``True``, draw a colored border around flushed areas.

# Widget name -> (import path, attribute). Core names live above.
_LAZY = {
    "Accordion": ("pdwidgets.widgets.accordion", "Accordion"),
    "AppBar": ("pdwidgets.widgets.app_bar", "AppBar"),
    "Badge": ("pdwidgets.widgets.badge", "Badge"),
    "BottomSheet": ("pdwidgets.widgets.bottom_sheet", "BottomSheet"),
    "Button": ("pdwidgets.widgets.button", "Button"),
    "Card": ("pdwidgets.widgets.card", "Card"),
    "Chart": ("pdwidgets.widgets.chart", "Chart"),
    "CheckBox": ("pdwidgets.widgets.check_box", "CheckBox"),
    "Chip": ("pdwidgets.widgets.chip", "Chip"),
    "ColorPicker": ("pdwidgets.widgets.color_picker", "ColorPicker"),
    "Column": ("pdwidgets.widgets.column", "Column"),
    "DatePicker": ("pdwidgets.widgets.date_picker", "DatePicker"),
    "Dialog": ("pdwidgets.widgets.dialog", "Dialog"),
    "DigitalClock": ("pdwidgets.widgets.digital_clock", "DigitalClock"),
    "Divider": ("pdwidgets.widgets.divider", "Divider"),
    "Drawer": ("pdwidgets.widgets.drawer", "Drawer"),
    "Dropdown": ("pdwidgets.widgets.dropdown", "Dropdown"),
    "Form": ("pdwidgets.widgets.form", "Form"),
    "FormRow": ("pdwidgets.widgets.form_row", "FormRow"),
    "Gauge": ("pdwidgets.widgets.gauge", "Gauge"),
    "Grid": ("pdwidgets.widgets.grid", "Grid"),
    "Icon": ("pdwidgets.widgets.icon", "Icon"),
    "IconButton": ("pdwidgets.widgets.icon_button", "IconButton"),
    "Image": ("pdwidgets.widgets.image", "Image"),
    "Keyboard": ("pdwidgets.widgets.keyboard", "Keyboard"),
    "Label": ("pdwidgets.widgets.label", "Label"),
    "ListView": ("pdwidgets.widgets.list_view", "ListView"),
    "Menu": ("pdwidgets.widgets.menu", "Menu"),
    "Navigator": ("pdwidgets.widgets.navigator", "Navigator"),
    "NumberStepper": ("pdwidgets.widgets.number_stepper", "NumberStepper"),
    "Page": ("pdwidgets.widgets.page", "Page"),
    "PasswordField": ("pdwidgets.widgets.password_field", "PasswordField"),
    "PinPad": ("pdwidgets.widgets.pin_pad", "PinPad"),
    "ProgressBar": ("pdwidgets.widgets.progress_bar", "ProgressBar"),
    "RadioButton": ("pdwidgets.widgets.radio_button", "RadioButton"),
    "RadioGroup": ("pdwidgets.widgets.radio_group", "RadioGroup"),
    "Row": ("pdwidgets.widgets.row", "Row"),
    "ScrollBar": ("pdwidgets.widgets.scroll_bar", "ScrollBar"),
    "ScrollView": ("pdwidgets.widgets.scroll_view", "ScrollView"),
    "SegmentedControl": ("pdwidgets.widgets.segmented_control", "SegmentedControl"),
    "Slider": ("pdwidgets.widgets.slider", "Slider"),
    "Spinner": ("pdwidgets.widgets.spinner", "Spinner"),
    "Switch": ("pdwidgets.widgets.switch", "Switch"),
    "TabView": ("pdwidgets.widgets.tab_view", "TabView"),
    "TextBox": ("pdwidgets.widgets.text_box", "TextBox"),
    "TextInput": ("pdwidgets.widgets.text_input", "TextInput"),
    "Toast": ("pdwidgets.widgets.toast", "Toast"),
    "Toggle": ("pdwidgets.widgets.toggle", "Toggle"),
    "ToggleButton": ("pdwidgets.widgets.toggle_button", "ToggleButton"),
}

__all__ = [
    "ALIGN",
    "DEBUG",
    "DEFAULT_PADDING",
    "ICON_SIZE",
    "MARK_UPDATES",
    "pct",
    "PAD",
    "POSITION",
    "TEXT_SIZE",
    "TEXT_WIDTH",
    "Area",
    "ColorTheme",
    "Display",
    "IconTheme",
    "Screen",
    "Task",
    "Widget",
    "events",
    "get_palette",
    "icon_theme",
    "tick",
]
__all__ += list(_LAZY.keys())


def __getattr__(name):
    """Lazily import a widget class listed in ``_LAZY``.

    Args:
        name: Public widget name (for example ``"Button"``).

    Returns:
        The resolved class or object.

    Raises:
        AttributeError: If ``name`` is not a known lazy export.
    """
    spec = _LAZY.get(name)
    if spec is None:
        raise AttributeError(f"module 'pdwidgets' has no attribute {name!r}")
    mod_path, attr = spec
    mod = __import__(mod_path, None, None, [attr])
    val = getattr(mod, attr)
    globals()[name] = val
    return val


def __dir__():
    """Return sorted public names including lazy widget exports."""
    return sorted(set(__all__) | set(globals().keys()))
